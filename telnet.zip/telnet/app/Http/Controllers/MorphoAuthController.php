<?php

namespace App\Http\Controllers;

use App\Services\MorphoApiService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class MorphoAuthController extends Controller
{
    protected MorphoApiService $morphoApiService;

    public function __construct(MorphoApiService $morphoApiService)
    {
        $this->morphoApiService = $morphoApiService;
    }

    /**
     * Authenticate with Morpho API
     *
     * @param Request $request
     * @return JsonResponse
     */
    public function authenticate(Request $request): JsonResponse
    {
        $result = $this->morphoApiService->authenticate();

        if ($result['success']) {
            // Return response in the same format as Morpho API
            return response()->json([
                'access_token' => $result['access_token'] ?? $result['token'],
                'token_type' => $result['token_type'] ?? 'bearer',
            ], 200);
        }

        return response()->json([
            'success' => false,
            'message' => 'Authentication failed',
            'error' => $result['error'] ?? 'Unknown error',
        ], $result['status'] ?? 500);
    }
}

